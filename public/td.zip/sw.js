const CACHE_NAME = 'dynamic-v78';
const CACHE_FILES = ['/assets/admin-DHccxuBM.js','/assets/admin-FAd44O-U.css','/assets/assets-115Q1gj_.css','/assets/assets-BEoAhgt3.css','/assets/assets-CRtW3LKj.js','/assets/assets-details-BL131Wa1.css','/assets/assets-details-BrBXaGQm.js','/assets/assets-details-Caa-oSwL.css','/assets/assets-details-CNEbBJkD.js','/assets/assets-mint-4OT9GVEU.js','/assets/assets-mint-_xICWYsO.css','/assets/assets-u0wxP4Q5.js','/assets/auth-D512X1QB.css','/assets/auth-Dnb5pkDe.js','/assets/base-D2s522XO.js','/assets/cardano_message_signing_bg-C4PrA0rD.wasm','/assets/cardano_serialization_lib_bg-DYSGQNOE.wasm','/assets/change-email-Bv3yxMrG.js','/assets/change-email-DmpAZ5tt.css','/assets/change-pin-Cgz41vTN.js','/assets/change-pin-DZUR0tc6.css','/assets/choose-tag-CYnV8y7E.css','/assets/choose-tag-C_B_zstE.js','/assets/ClipboardUtils-KPcFGzWs.js','/assets/dash-BaAjjTSY.css','/assets/dash-Bw13yGID.js','/assets/demo-auth-DuQICxMy.js','/assets/demo-auth-HU-UfmdW.css','/assets/demo-B21H0CHY.css','/assets/demo-B_9fsnOT.js','/assets/DeviceMetadataService-D_CYGXek.js','/assets/event-details-D4CtE9Tb.js','/assets/event-details-D9K0LOtU.css','/assets/events-CKlZC7Vd.js','/assets/events-DMZqK-Hk.css','/assets/focus-visible-supuXXMI.js','/assets/index-6MWipCBG.js','/assets/index-AJE8xikL.css','/assets/index-BDiQ-Dk0.css','/assets/index-BJCX-6Gs.js','/assets/index-CiyKClrF.js','/assets/index-DpAJXa02.js','/assets/index9-B7oN0YMx.js','/assets/input-shims-9nV2YuRW.js','/assets/InstantUpdateService-DhfZMUId.js','/assets/ios.transition-KUMBTd09.js','/assets/jszip.min-BytVBSOY.js','/assets/local-wallets-BGN8rIO4.js','/assets/local-wallets-Clst7z5H.css','/assets/LocalWalletTabBar.vue_vue_type_script_setup_true_lang-DJwYFhSC.js','/assets/lottery-1S-zq_7v.css','/assets/lottery-CHXKYeMS.js','/assets/main-6XmwJdEB.css','/assets/main-B6rhHeoE.css','/assets/main-BgQ-6JAl.css','/assets/main-CAxJFS2R.css','/assets/main-Cx4-lYSk.js','/assets/main-D-Dbspf9.js','/assets/main-DUNTY_yH.js','/assets/main-ZKs6RutG.js','/assets/md.transition-B80L5z_d.js','/assets/my-tags-BGt3tHkO.js','/assets/my-tags-tw2HRwBa.css','/assets/my-wallets-ClZo5V2p.css','/assets/my-wallets-DYJ8okTx.js','/assets/MyWalletTabBar.vue_vue_type_script_setup_true_lang-97ezf0yi.js','/assets/native-C3xthRaw.js','/assets/new-local-wallet-DzBVt3-m.js','/assets/new-local-wallet-tXsNK5J4.css','/assets/new-my-wallet-7ysijH69.css','/assets/new-my-wallet-BEUOa31y.js','/assets/new-secret-C-Z_P-o7.js','/assets/new-secret-FCfMHlpJ.css','/assets/new-tag-B9EYZw6i.js','/assets/new-tag-BGk0qDJy.js','/assets/new-tag-BRvfvawG.css','/assets/new-tag-fDdm9WU6.css','/assets/NFCModal-C0eRs6qg.js','/assets/NFCModal-v-Ibgn0c.css','/assets/NFCModalPetro-Cdk6hmpb.js','/assets/NFCModalPetro-CubWHtne.css','/assets/poa-CPKUEF17.css','/assets/poa-DiAjdRJQ.js','/assets/poa-verify-BU3UaxJs.js','/assets/poa-verify-CzBKURof.css','/assets/PriceChart-DDY7ruk8.css','/assets/PriceChart.vue_vue_type_style_index_0_lang-DMqDPMkK.js','/assets/secret-CNtclVVp.css','/assets/secret-DfGKebte.js','/assets/SeedVaultTabBar.vue_vue_type_script_setup_true_lang-aZPAAxJC.js','/assets/settings-B51Q8GHh.js','/assets/settings-BHZ3VnFB.css','/assets/settings-BjfpicnV.css','/assets/settings-C43umKOB.js','/assets/settings-CpJlEltH.css','/assets/settings-CSzhL-R1.css','/assets/settings-CZsF0-5l.js','/assets/settings-DnWVHk3Z.css','/assets/settings-DZ-Exw62.js','/assets/settings-oSYiIDp7.js','/assets/signed-CiGdP1Li.css','/assets/signed-DkApJMxq.js','/assets/signing-BmJ4ZKht.js','/assets/signing-Crmh85YU.css','/assets/status-tap-Brb4H7sg.js','/assets/swipe-back-k1s7nosJ.js','/assets/TagTabBar.vue_vue_type_script_setup_true_lang-BLO0pgNV.js','/assets/TapDanoService-BXvqi_re.js','/assets/test-B9fFFH_1.js','/assets/test-BPtUVJWl.css','/assets/transactions-C5ZySWg4.js','/assets/transactions-D9kaBuX6.js','/assets/ValidationService-DHkG1lX8.js','/assets/WalletStorageService-DwYzgozj.js','/assets/WalletTypes-DYSF_s2P.js','/assets/web-21-BJNqZ.js','/assets/web-CI3iHwJ-.js','/assets/web-D8H9XpZX.js','/assets/web-DkMznQp1.js','/assets/web-HuqzEoCJ.js','/assets/welcome-Ck7V8T7w.js','/assets/welcome-u_DSymdV.css','/br.png','/check.png','/favicon.png','/grafismo.png','/index.html','/logo-black.png','/logo-petrobras.png','/logo.png','/logo2.png','/lottery.mp3','/manifest.json','/msgpack.min.js','/noble-ed25519.js','/proof.png'];

self.addEventListener('message', (event) => {
  if (event.data.action === 'skipWaiting') {
    self.skipWaiting();
  } else if (event.data.action === 'getCacheName') {
    event.ports[0].postMessage(CACHE_NAME);
  }
});

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(CACHE_FILES);
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cache => {
          if (cache !== CACHE_NAME) {
            console.log('Service Worker: Deleting old cache:', cache);
            return caches.delete(cache);
          }
        })
      );
    })
  );
  return self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const isLocalhost = event.request.url.includes('localhost') || event.request.url.includes('192.168');
  const url = new URL(event.request.url);
  if ((url.origin === location.origin) && !isLocalhost) {
    event.respondWith(
      caches.match(event.request).then(response => {
        return response || fetch(event.request).then(fetchRes => {
          return caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request.url, fetchRes.clone());
            return fetchRes;
          });
        });
      })
    );
  } else {
    event.respondWith(fetch(event.request));
  }
});