import{bo as a,__tla as r}from"./index-DpAJXa02.js";let t,e=Promise.all([(()=>{try{return r}catch{}})()]).then(async()=>{t=a()});export{e as __tla,t as c};
