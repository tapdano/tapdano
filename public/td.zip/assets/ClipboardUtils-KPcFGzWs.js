const t=async a=>{try{a&&await navigator.clipboard.writeText(a)}catch(o){console.error("Failed to copy: ",o)}};export{t as c};
